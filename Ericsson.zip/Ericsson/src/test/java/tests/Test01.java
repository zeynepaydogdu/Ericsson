package tests;



import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.AmazonPage;
import utilities.ConfigReader;
import utilities.Driver;


public class Test01 {
    AmazonPage page=new AmazonPage();
    Actions actions=new Actions(Driver.getDriver());



    @BeforeClass
    public void loginTest(){
        Driver.getDriver().get(ConfigReader.getProperty("amazon_url"));
        Assert.assertEquals(Driver.getDriver().getCurrentUrl(), ConfigReader.getProperty("amazon_url"));
        page.cerezKabul.click();
        actions.moveToElement(page.loginHareket).perform();
        page.girisYap.click();
        page.ePosta.sendKeys(ConfigReader.getProperty("email"));
        page.devamButonu.click();
        page.sifre.sendKeys(ConfigReader.getProperty("sifre"));
        page.signIn.click();
    }
    @Test
    public void urunArama() throws InterruptedException {

        page.searchBox.sendKeys(ConfigReader.getProperty("arananUrun") + Keys.ENTER);
        for (int i =0; i<page.samsungResult.size();i++) {
            System.out.println(page.samsungResult.get(i).getText());
            Assert.assertTrue(page.samsungResult.get(i).getText().toLowerCase().contains(ConfigReader.getProperty("urun").toLowerCase()));
           // Assert.assertTrue(page.samsungResult.get(i).getText().contains(ConfigReader.getProperty("urun")));
        }

        Assert.assertTrue(page.urun.isDisplayed());
        System.out.println(page.urun.getText());
        System.out.println("=============================");
        System.out.println(page.urunFiyat.getText());
        page.urun.click();
        page.addList.click();
        actions.sendKeys(Keys.DOWN).perform();
        page.newList.click();
        page.creatList.click();
//            if (page.newList==null){
//                page.creatList.click();
//            }

         //page.listeAc.click();
        //page.addList.click();
        Thread.sleep(3000);
        page.listeyiGoruntule.click();
        Assert.assertTrue(page.urunDogrula.isDisplayed());

        page.delete.click();
        Thread.sleep(3000);
        Assert.assertTrue(page.deleteAssert.isDisplayed());



    }


}